import React from "react";
import { Route } from "react-router-dom";

import Main from "./pages/Main";
import SignUp from "./pages/SignUp";
import Seminars from "./pages/Seminars";
import Journal from "./pages/Journal";
import News from "./pages/News";
import LeagueArr from "./pages/LeagueArrenuis";
import Contacts from "./pages/Contacts"
import Login from "./pages/Login";
import Exam from "./pages/Exam";
import NewsArrenius from "./pages/NewsArrenius";
import RegistrIns from "./pages/reginstru";
import Admin from "./pages/Admin";
import NewsUchrsobr from "./pages/newspages/newsUchrsobr";

export const ROUTES = [
    {
        path: "/",
        key: "ROOT",
        exact: true,
        component: Main,
    },
    {
        path: "/login",
        key: "LOGIN",
        exact: true,
        component: Login,
    },
    {
        path: "/seminar",
        key: "SEMINAR",
        exact: true,
        component: Seminars,
    },
    {
        path: "/journal",
        key: "JOURNAL",
        exact: true,
        component: Journal,
    },
    {
        path: "/news",
        key: "NEWS",
        exact: true,
        component: News,
    },
    {
        path: "/leagueArr",
        key: "LEAGUEARR",
        exact: true,
        component: LeagueArr,
    },
    {
        path: "/contacts",
        key: "CONTACTS",
        exact: true,
        component: Contacts,
    },
    {
        path: "/register",
        key: "REGISTER",
        exact: true,
        component: SignUp,
    },
    {
        path: "/exam",
        key: "EXAM",
        exact: true,
        component: Exam,
    },
    {
        path: "/newsArrenius",
        key: "NEWSARRENIUS",
        exact: true,
        component: NewsArrenius,
    },
    {
        path: "/reginstu",
        key: "REGINSTU",
        exact: true,
        component: RegistrIns,
    },
    {
        path: "/admin",
        key: "ADMIN",
        exact: true,
        component: Admin,
    },
    {   path: "/newsUchrsobr",
        key: "NEWSUCHRSOBR",
        exact: true,
        component: NewsUchrsobr,
    },

]

export function getRoute(route, state, setState) {
    return (
      <Route
        path={route.path}
        exact={route.exact}
        key={route.key}
        render={(props) => <route.component {...props} state={state} setState={setState} />}
      />
    );
  }