import { configureStore } from "@reduxjs/toolkit";
import storage from "redux-persist/lib/storage";
import { combineReducers } from "redux";
import { persistReducer } from "redux-persist";
import thunk from "redux-thunk";
import examReducer from "./slices/examSlice"
import startExamReducer from "./slices/startExamSlice"

// redux-persist makes bearer token or any slice chosen not change
// if the page refreshes

const reducers = combineReducers({
    exam: examReducer,
    startExam: startExamReducer,
});

const persistConfig = {
  key: "root",
  blacklist: ["exam", "startExam"],
  storage,
};

const persistedReducer = persistReducer(persistConfig, reducers);

const store = configureStore({
  reducer: persistedReducer,
  devTools: process.env.NODE_ENV !== "production",
  middleware: [thunk],
});

export default store;