/* eslint-disable no-param-reassign */
import { createSlice } from "@reduxjs/toolkit";

const initialExamState = {
  examStarted: false,
  remainingTime: "",
  endTime: "",
  startTime: "",
  examIsFinished: false,
};

const startExamSlice = createSlice({
  name: "startExam",
  initialState: initialExamState,
  reducers: {
    startExam(state) {
      state.examStarted = !state.examStarted;
      const today = new Date();
      state.startTime =
        today.getHours() * 3600 + today.getMinutes() * 60 + today.getSeconds();
      state.endTime = state.startTime + 5400;
      state.examIsFinished = false;
    },
    updateTime(state) {
      const today = new Date();
      state.startTime =
        today.getHours() * 3600 + today.getMinutes() * 60 + today.getSeconds();
    },
    finishExam(state) {
      state.examIsFinished = true;
    },
  },
});

export const startExamActions = startExamSlice.actions;
export default startExamSlice.reducer;
