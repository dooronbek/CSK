/* eslint-disable no-param-reassign */
import { createSlice } from "@reduxjs/toolkit";

const initialExamState = {
  examAnswer: [],
};

const examSlice = createSlice({
  name: "exam",
  initialState: initialExamState,
  reducers: {
    putAnswer(state, action) {
      const myAnswer = action.payload;
      let notInList = true;
      for (let i = 0; i < state.examAnswer.length; i++) {
        if (myAnswer.questionNumber === state.examAnswer[i].questionNumber){
          state.examAnswer[i].answer = myAnswer.answer;
          notInList = false;
        }
      }
      if (notInList) {
        state.examAnswer = state.examAnswer.concat(action.payload);
      }
    },
  },
});

export const examActions = examSlice.actions;
export default examSlice.reducer;