import firebase from "firebase/compat/app";
import "firebase/compat/firestore"
import "firebase/compat/auth";

const firebaseConfig = {
    apiKey: "AIzaSyCME85Q6GJIMMblfUFlrtFJhW2wjmUFBHI",
    authDomain: "chemolympics-85277.firebaseapp.com",
    projectId: "chemolympics-85277",
    storageBucket: "chemolympics-85277.appspot.com",
    messagingSenderId: "949667407332",
    appId: "1:949667407332:web:312d6b7227b87dd92e93f1",
    measurementId: "G-LSSX4C12WD",
  };

firebase.initializeApp(firebaseConfig);
const db = firebase.firestore();
const auth = firebase.auth();;
export {auth, firebase, db};
