import React, { useState } from "react";
import { BrowserRouter } from "react-router-dom";
import { ROUTES, getRoute } from "./Routes"

const App = () => {
  const [state, setState] = useState();
  return (
    <BrowserRouter>
      <>{ROUTES.map((obj) => getRoute(obj, state, setState))}</>
    </BrowserRouter>
  );
}

export default App;
