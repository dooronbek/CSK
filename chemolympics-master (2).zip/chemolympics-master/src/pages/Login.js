import React, { useState } from "react";
import { NavLink } from "reactstrap";
import MyNavbar from "../components/MyNavbar";
import { firebase, auth } from "../config/firebaseConfig";
import background from "../images/mainBackgroundImage.JPG";

import "../styles/SignUp.css";

const Login = () => {
  const [myNumber, setMyNumber] = useState("");
  const [otp, setotp] = useState("");
  const [show, setshow] = useState(false);
  const [final, setfinal] = useState("");

  //   useEffect(() => {
  //     let isMounted = true;
  //     if (isMounted) {
  //       console.log(myNumber);
  //     }
  //     return () => (isMounted = false);
  //   }, [myNumber]);

  const handleSignIn = (event) => {
    event.preventDefault();

    if (myNumber === "" || myNumber.length < 10) {
      alert(
        "Пожалуйста напишите ваш номер правильно прежде чем нажать на кнопку Войти"
      );
      return;
    }

    let verify = new firebase.auth.RecaptchaVerifier("recaptcha-container", {
      size: "invisible",
    });
    auth
      .signInWithPhoneNumber(myNumber, verify)
      .then((result) => {
        setfinal(result);
        console.log("result", result);
        setshow(true);
      })
      .catch((err) => {
        alert(err);
        window.location.reload();
      });

    console.log(myNumber);
  };

  const ValidateOtp = () => {
    if (otp === null || final === null) return;
    final
      .confirm(otp)
      .then((result) => {
        // success
        console.log("result is ", result);
        window.location.href = "/exam";
      })
      .catch((err) => {
        alert("Неверный пароль");
      });
  };
  return (
    <div className="row">
      <MyNavbar />
      <div
        className="form-body"
        style={{
          backgroundImage: `url(${background})`,
          width: "100%",
          height: "100%",
        }}
      >
        <div className="form-holder">
          {!show && (
            <div className="form-content">
              <div className="form-items">
                <h3>Логин</h3>
                <form
                  className="requires-validation"
                  noValidate
                  onSubmit={handleSignIn}
                >
                  <div className="col-md-12">
                    <label>Номер телефона</label>
                    <input
                      className="form-control"
                      type="tel"
                      name="thisNumber"
                      placeholder="+996996996"
                      required
                      onChange={(e) => {
                        setMyNumber(e.target.value);
                      }}
                    />
                    <div id="recaptcha-container"></div>
                  </div>
                  <div className="form-button mt-3">
                    <button
                      id="submit"
                      type="submit"
                      className="float-right btn btn-primary"
                    >
                      Войти
                    </button>
                  </div>
                </form>
                <NavLink href="/register" className="btn w-25">
                  Регистрация
                </NavLink>
              </div>
            </div>
          )}
          <div style={{ display: show ? "block" : "none" }}>
            <input
              type="text"
              placeholder={"Введите пароль"}
              onChange={(e) => {
                setotp(e.target.value);
              }}
            ></input>
            <br />
            <br />
            <button onClick={ValidateOtp}>Подвердить</button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
