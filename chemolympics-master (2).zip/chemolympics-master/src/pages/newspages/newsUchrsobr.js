import React from "react";
import News2 from "../../images/uchrsobr.jpg";
import MyNavbar from "../../components/MyNavbar";
import "../../styles/NewsArrenius.css"

const NewsUchrsobr = () => {
    return (
        <>
      <MyNavbar />
      <section>
          <div className="container">
      <div>
        <h1>Учредительское Собрание нашего сообщества</h1>
      </div>
      <div className="block a2maintextblock ">

<div className="text-image-block hashtaglink">

    
    
        <time className="text-image-block__date" datetime="2021-10-08 12:00">16.10.2021
</time>

        <div className="text-image-block__bd">
            <p><strong>Отличные новости для школьников. Регистрация на лигу Аррениус 2021 по химии открыта.</strong></p>

<p>16 Октября 2021 года в городе Бишкек в конференц зале кофейни Sierra на Душанбинке, состоялось учредительское собрание Общественного Объединения
    "Химическое Сообщество Кыргызстана". Присутсвовали 8 человек. Собрание утвердило устав и  Организационный Комитет,
    список учредителей и протокол собрания были нотариально заверены.</p>
<h5>Организационный Комитет (ОК):</h5>
<p>
Председатель - Дооронбек Маметов<br/>
Секретарь - Адилет Рахманбердиев<br/>
Член ОК - Шаршенали Сайткулов<br/>
Член ОК - Камиль Кубанычбек<br/>
</p>
        </div>
        <div className="text-image-block__img">
            
        <img className="slimmage hashtaglink" src={News2} width="300" height="300"></img>


        </div>
            
</div>
</div></div></section>
    </>
    )
}

export default NewsUchrsobr;