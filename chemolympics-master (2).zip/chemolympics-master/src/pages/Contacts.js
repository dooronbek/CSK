import React from "react";
import MyNavbar from "../components/MyNavbar";
import background from "../images/mainBackgroundImage.JPG";

const Constacts = () => {
  return (
    <>
      <MyNavbar />
      <div
        style={{
          backgroundImage: `url(${background})`,
          width: "100%",
          height: "1000px",
        }}
      >
        <h1>Наш телефон: 0990 552 713 </h1>
        <h1>Наш имейл: chemsockgz@gmail.com</h1>
      </div>
    </>
  );
};

export default Constacts;
