import React, { useEffect } from "react";
import MyNavbar from "../components/MyNavbar";
import { auth, db } from "../config/firebaseConfig";
import { useAuthState } from "react-firebase-hooks/auth";
import { onSnapshot, collection } from "@firebase/firestore";
import background from "../images/mainBackgroundImage.JPG";
import "../styles/SignUp.css";

const Admin = () => {
  const [user] = useAuthState(auth);

  const myInput = {
    name: "",
    school: "",
    grade: "",
    teacher: "",
    region: "",
    email: "",
    number: "",
  };

  const handleInputChange = (event) => {
    const value = event.target.value;
    const name = event.target.name;
    // console.log("event", event);
    console.log("name", name);
    console.log("value ", value);
    if (name === "name") {
      myInput.name = value;
    }
    if (name === "school") {
      myInput.school = value;
    }
    if (name === "grade") {
      myInput.grade = value;
    }
    if (name === "teacher") {
      myInput.teacher = value;
    }
    if (name === "region") {
      myInput.region = value;
    }
    if (name === "thisEmail") {
      myInput.email = value;
    }
    if (name === "thisNumber") {
      myInput.number = value;
    }
    console.log("My input is", myInput);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (
      myInput.name === "" ||
      myInput.school === "" ||
      myInput.grade === "" ||
      myInput.teacher === "" ||
      myInput.region === "" ||
      myInput.email === "" ||
      myInput.number === ""
    ) {
      alert(
        "Пожалуйста, заполните все прежде чем нажать на кнопку Зарегистрироваться"
      );
      return;
    }
    if (user) {
      db.collection("participants").add(myInput);
    }
  };

  useEffect(() => {
    onSnapshot(collection(db, "participants"), (snapshot) => {
      console.log(
        "snapshot is",
        snapshot.docs.map((doc) => doc.data())
      );
    });
  }, []);
  return (
    <div>
      <MyNavbar />
      <div
        className="form-body"
        style={{
          backgroundImage: `url(${background})`,
          width: "100%",
          height: "100%",
        }}
      >
        <div className="row">
          <div className="form-holder">
            <div className="form-content">
              <div className="form-items">
                <h3>Регистрация</h3>
                <p>Заполните данные ниже</p>
                <form
                  className="requires-validation"
                  noValidate
                  onSubmit={handleSubmit}
                >
                  <div id="recaptcha-container"></div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="name"
                      placeholder="ФИО"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="school"
                      placeholder="Школа"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="number"
                      name="grade"
                      placeholder="Класс"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="teacher"
                      placeholder="Учитель"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="region"
                      placeholder="Область"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="email"
                      name="thisEmail"
                      placeholder="Имейл"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <label>Номер телефона</label>
                    <input
                      className="form-control"
                      type="tel"
                      name="thisNumber"
                      placeholder="+996996996"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="form-button mt-3">
                    <button
                      id="submit"
                      type="submit"
                      className="btn btn-primary"
                    >
                      Зарегистрироваться
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;
