import React from "react";
import News1 from "../images/news1.jpg";
import MyNavbar from "../components/MyNavbar";
import "../styles/NewsArrenius.css";

const NewsArrenius = () => {
  return (
    <>
      <MyNavbar />
      <section>
        <div className="container">
          <div>
            <h1>Лига Аррениус 2021!</h1>
          </div>
          <div className="block a2maintextblock ">
            <div className="text-image-block hashtaglink">
              <time
                className="text-image-block__date"
                datetime="2021-10-08 12:00"
              >
                13.10.2021
              </time>

              <div className="text-image-block__bd">
                <p>
                  <strong>
                    Отличные новости для школьников. Регистрация на лигу
                    Аррениус 2021 по химии открыта.
                  </strong>
                </p>

                <p>
                  Лига Аррениус это серия экзаменов организованных "Химическим
                  Сообществом Кыргызстана" и проектом Аррениус для популяризации
                  химии в Кыргызстане. Первый тур пройдет уже 24 Октября 2021
                  года. Этот тур будет онлайн, а все последующие будут
                  проводиться в очном формате. Стоимость участия - 200 сом.{" "}
                  <a href="/leagueArr/">Подробнее о лиге здесь.</a>
                </p>
                <h5>Инструкция по регистрации и оплате взноса</h5>
                <p>
                  Сначала надо зарегистрироваться{" "}
                  <a href="https://linktr.ee/chemolympic">здесь.</a> А затем:{" "}
                  <br />
                  1) через платежные терминалы "Айыл Банк", Pay 24, Quick Pay,
                  UMAI, заходите в раздел "Электронные кошельки" / или "Услуги
                  банков" - и выбираете "MBank Online - поплнение" ;<br />
                  2) набираете 996779854433;
                  <br />
                  3) вносите 200 сом;
                  <br />
                  4) забираете чек и отправляете на WhatsApp номер 0990-552-713;
                  <br />
                  5) вы успешно подтвердили свое участие в Лиге!
                </p>
              </div>
              <div className="text-image-block__img">
                <img
                  className="slimmage hashtaglink"
                  src={News1}
                  width="300"
                  height="300"
                  alt="someImage"
                ></img>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default NewsArrenius;
