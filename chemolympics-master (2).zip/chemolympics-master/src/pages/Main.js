import React from "react";
import MyNavbar from "../components/MyNavbar";
import { MyNews } from "./News";
import Mission from "../components/Mission";
import background from "../images/mainBackgroundImage.JPG"
import logo1 from "../images/logo1.png"
import "../styles/App.css"

const Main = () => {
  return (
    <div style={{
      //backgroundImage: `url(${background})`,
      width: '100%',
      height: '100%'
      }}>
      <div>
        <MyNavbar/>
          <><div id="index_line">
            <div id="slider">
                <img className="welcmess"alt="" height="240" src={logo1} width="450"></img></div>

            <div id="slider_description">
                <h1>Кыргызстан Химия Коому</h1>
                <p>Это сообщество было создано для объединения и сотрудничества наших граждан работающих или учащихся в химической сфере в Кыргызстане и за рубежом. Основной целью сообщества считается вклад в развитие химической отрасли Кыргызстана.</p>
            </div>


        </div></>


        <MyNews/>
      </div>
    </div>
  );
}

export default Main;
