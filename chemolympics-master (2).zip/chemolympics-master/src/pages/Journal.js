import React from "react";
import MyNavbar from "../components/MyNavbar";
import background from "../images/mainBackgroundImage.JPG";

const Journal = () => {
    return (
        <>
      <MyNavbar />
      <div
      >
        <h1>В стадии разработки </h1>
      </div>
    </>
    )
}

export default Journal;