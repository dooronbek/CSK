import React from "react";
import News1 from "../images/news1.jpg";
import News2 from "../images/uchrsobr.jpg";
import MyNavbar from "../components/MyNavbar";
import "../styles/News.css"

const News = () => {
  return (
    <div>
      <MyNavbar />
      <div className="NewS_filter__container__2iLQc">

<a href="/newsUchrsobr/"><div className="NewS_news__card__2c6kw">
  <img className="NewS_news__card_img__3zLzE" src={News2} alt="">
    </img>
    <div className="NewS_news__text__1ecJ7">
      <div className="NewS_news__card_head__22Yfc">Состоялось Учредительское Собрание нашего сообщества</div>
      <div>
        <div className="NewS_news__card_description__2faLs">
          <p><strong><span>
            <span>16 Октября 2021 года в городе Бишкек состоялось учредительское собрание Общественного объединения
              "Химическое Сообщество Кыргызстана". В этот день собрание утвердило устав и  Организационный Комитет,
              список учредителей и протокол собрания были нотариально заверены.
            </span>
            </span>
            </strong></p>

<p>&nbsp;</p>

<p><span><span><strong>Дата</strong>16.10.2021</span></span></p></div></div><p className="NewS_more_info__2MNc3">Читать полностью</p></div></div></a></div>

      <div className="NewS_filter__container__2iLQc">

    <a href="/newsArrenius/"><div className="NewS_news__card__2c6kw">
      <img className="NewS_news__card_img__3zLzE" src={News1} alt="">
        </img>
        <div className="NewS_news__text__1ecJ7">
          <div className="NewS_news__card_head__22Yfc">Лига Аррениус 2021!</div>
          <div>
            <div className="NewS_news__card_description__2faLs">
              <p><strong><span>
                <span>Регистрация на лигу Аррениус 2021 началась...</span>
                </span>
                </strong></p>

<p>&nbsp;</p>

<p><span><span><strong>Дата</strong>13.10.2021</span></span></p></div></div><p className="NewS_more_info__2MNc3">Читать полностью</p></div></div></a></div>
    
    </div>
  );
};

export const MyNews = () => {
  return (



    <><div className="NewS_filter__container__2iLQc">

      <a href="/newsUchrsobr/"><div className="NewS_news__card__2c6kw">
        <img className="NewS_news__card_img__3zLzE" src={News2} alt="">
        </img>
        <div className="NewS_news__text__1ecJ7">
          <div className="NewS_news__card_head__22Yfc">Состоялось Учредительское Собрание нашего сообщества</div>
          <div>
            <div className="NewS_news__card_description__2faLs">
              <p><strong><span>
                <span>16 Октября 2021 года в городе Бишкек состоялось учредительское собрание Общественного объединения
                  "Химическое Сообщество Кыргызстана". В этот день собрание утвердило устав и  Организационный Комитет,
                  список учредителей и протокол собрания были нотариально заверены.
                </span>
              </span>
              </strong></p>

              <p>&nbsp;</p>

              <p><span><span><strong>Дата</strong>16.10.2021</span></span></p></div></div><p className="NewS_more_info__2MNc3">Читать полностью</p></div></div></a></div><div className="NewS_filter__container__2iLQc">

        <a href="/newsArrenius/"><div className="NewS_news__card__2c6kw">
          <img className="NewS_news__card_img__3zLzE" src={News1} alt="">
          </img>
          <div className="NewS_news__text__1ecJ7">
            <div className="NewS_news__card_head__22Yfc">Лига Аррениус 2021!</div>
            <div>
              <div className="NewS_news__card_description__2faLs">
                <p><strong><span>
                  <span>Регистрация на лигу Аррениус 2021 началась...</span>
                </span>
                </strong></p>

                <p>&nbsp;</p>

                <p><span><span><strong>Дата:</strong>13.10.2021</span></span></p></div></div><p className="NewS_more_info__2MNc3">Читать полностью</p></div></div></a></div></>
  );
};

export default News;
