import React from "react";
import MyNavbar from "../components/MyNavbar";
import { firebase } from "../config/firebaseConfig";
import background from "../images/mainBackgroundImage.JPG";
import "../styles/SignUp.css";

const SignUp = () => {
  const myInput = {
    name: "",
    school: "",
    grade: "",
    teacher: "",
    region: "",
    district: "",
    schoolType: "",
    language: "",
    date: "",
    email: "",
    number: "",
  };
  const handleInputChange = (event) => {
    const value = event.target.value;
    const name = event.target.name;
    // console.log("event", event);
    console.log("name", name);
    console.log("value ", value);
    if (name === "name") {
      myInput.name = value;
    }
    if (name === "school") {
      myInput.school = value;
    }
    if (name === "grade") {
      myInput.grade = value;
    }
    if (name === "teacher") {
      myInput.teacher = value;
    }
    if (name === "region") {
      myInput.region = value;
    }
    if (name === "district") {
      myInput.district = value;
    }
    if (name === "schoolType") {
      myInput.schoolType = value;
    }
    if (name === "language") {
      myInput.language = value;
    }
    if (name === "thisDate") {
      myInput.date = value;
    }
    if (name === "thisEmail") {
      myInput.email = value;
    }
    if (name === "thisNumber") {
      myInput.number = value;
    }
    console.log("My input is", myInput);
  };

  const setUpRecaptcha = () => {
    window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier(
      "recaptcha-container",
      {
        size: "invisible",
        callback: (response) => {
          // reCAPTCHA solved, allow signInWithPhoneNumber.
          console.log("response is ", response);
          onSignInSubmit();
        },
      }
    );
  };
  const getCodeFromUserInput = () => {
    console.log("got code");
  };
  const onSignInSubmit = (event) => {
    event.preventDefault();
    setUpRecaptcha()
    const phoneNumber = myInput.number;
    const appVerifier = window.recaptchaVerifier;
    firebase
      .auth()
      .signInWithPhoneNumber(phoneNumber, appVerifier)
      .then((confirmationResult) => {
        // SMS sent. Prompt user to type the code from the message, then sign the
        // user in with confirmationResult.confirm(code).
        window.confirmationResult = confirmationResult;
        const code = getCodeFromUserInput();
        confirmationResult
          .confirm(code)
          .then((result) => {
            // User signed in successfully.
            const user = result.user;
            console.log("user is ", user);
          })
          .catch((error) => {});

        // ...
      })
      .catch((error) => {
        // Error; SMS not sent
        // ...
      });
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (
      myInput.name === "" ||
      myInput.school === "" ||
      myInput.grade === "" ||
      myInput.teacher === "" ||
      myInput.region === "" ||
      myInput.district === "" ||
      myInput.schoolType === "" ||
      myInput.language === "" ||
      myInput.date === "" ||
      myInput.email === "" ||
      myInput.number === ""
    ) {
      alert(
        "Пожалуйста, заполните все прежде чем нажать на кнопку Зарегистрироваться"
      );
      return;
    }
    onSignInSubmit(event);
  };
  return (
    <div>
      <MyNavbar />
      <div
        className="form-body"
        style={{
          backgroundImage: `url(${background})`,
          width: "100%",
          height: "100%",
        }}
      >
        <div className="row">
          <div className="form-holder">
            <div className="form-content">
              <div className="form-items">
                <h3>Регистрация</h3>
                <p>Заполните данные ниже</p>
                <form
                  className="requires-validation"
                  noValidate
                  onSubmit={handleSubmit}
                >
                  <div id="recaptcha-container"></div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="name"
                      placeholder="ФИО"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="school"
                      placeholder="Школа"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="number"
                      name="grade"
                      placeholder="Класс"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="teacher"
                      placeholder="Учитель"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="region"
                      placeholder="Область"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="district"
                      placeholder="Район"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="text"
                      name="schoolType"
                      placeholder="Tип школы"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <select
                      defaultValue=""
                      className="form-control"
                      name="language"
                      required
                      onChange={handleInputChange}
                    >
                      <option value="" disabled>
                        Язык обучения
                      </option>
                      <option value="russian">Русский</option>
                      <option value="kyrgyz">Кыргызча</option>
                    </select>
                  </div>
                  <div className="col-md-12">
                    <label>Дата рождения</label>
                    <input
                      className="form-control"
                      type="date"
                      name="thisDate"
                      placeholder="Дата рождения"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <input
                      className="form-control"
                      type="email"
                      name="thisEmail"
                      placeholder="Имейл"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="col-md-12">
                    <label>Номер телефона</label>
                    <input
                      className="form-control"
                      type="tel"
                      name="thisNumber"
                      placeholder="+996996996"
                      required
                      onChange={handleInputChange}
                    />
                  </div>
                  <div className="form-button mt-3">
                    <button
                      id="submit"
                      type="submit"
                      className="btn btn-primary"
                    >
                      Зарегистрироваться
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
