import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { auth, db } from "../config/firebaseConfig";
import { useAuthState } from "react-firebase-hooks/auth";
import { onSnapshot, collection } from "@firebase/firestore";

import background from "../images/mainBackgroundImage.JPG";
import MyNavbar from "../components/MyNavbar";
// import {FirstPart, SecondPart} from "../components/multipleChoice";
import Variant4 from "../components/Variant4";
import Questions from "../components/ExamQuestion/Questions";
import Time from "../components/timer/Time";
import "../styles/Exam.css";
import { startExamActions } from "../store/slices/startExamSlice";
import "../components/multipleChoice/index.css";

const Exam = () => {
  const [user] = useAuthState(auth);
  const dispatch = useDispatch();
  const [examTime, setExamTime] = useState(false);

  const examAnswers = useSelector((state) => state.exam.examAnswer);
  const examIsFinished = useSelector((state) => state.startExam.examIsFinished);
  const examStarted = useSelector((state) => state.startExam.examStarted);

  const handleExamStart = () => {
    dispatch(startExamActions.startExam());
  };

  const today = new Date();
  const todayInSeconds =
    today.getHours() * 3600 + today.getMinutes() * 60 + today.getSeconds();
  const startTime = 36000; // after time would change into these
  const endTime = 41700;

  useEffect(() => {
    if (todayInSeconds >= startTime && todayInSeconds <= endTime) {
      setExamTime(true);
    }
  }, [todayInSeconds]);
  useEffect(() => {
    let isMounted = true;
    if (isMounted) {
      if (examIsFinished && user) {
        db.collection("users").add({
          examAnswers: examAnswers,
          userId: user.uid,
          phoneNumber: user.phoneNumber,
        });
        onSnapshot(collection(db, "users"), (snapshot) => {
          console.log("snapshot is", snapshot);
        });
      }
    }
    onSnapshot(collection(db, "users"), (snapshot) => {
      console.log(
        "snapshot is",
        snapshot.docs.map((doc) => doc.data())
      );
    });
    return () => {
      isMounted = false;
    };
  }, [examIsFinished]);

  return (
    <div>
      <MyNavbar />
      <div
        className="form-body"
        style={{
          backgroundImage: `url(${background})`,
          width: "100%",
          height: "105%",
        }}
      >
        {examTime && (
          <div>
            {user && (
              <>
                {!examStarted && <button
                  className="btn btn-secondary margin"
                  onClick={handleExamStart}
                >
                  Начать экзамен
                </button>}
                {examStarted && !examIsFinished && <button
                  className="btn btn-danger margin"
                  onClick={() => dispatch(startExamActions.finishExam())}
                >
                  Закончить экзамен
                </button>}
              </>
            )}
            {user && examStarted && !examIsFinished && (
              <div className="">
                <Time />
                <Questions />
                <Variant4 className="d-block" />
                {/* <FirstPart />
              <SecondPart /> */}
              </div>
            )}
            {!user && <div>Сначала войдите </div>}
            {user && examIsFinished && (
              <h1>Экзам закончился, результаты выйдут потом </h1>
            )}
          </div>
        )}
        {!examTime && <h1>Сейчас не время экзамена. Экзамен начнётся в 10:00</h1>}
      </div>
    </div>
  );
};

export default Exam;
