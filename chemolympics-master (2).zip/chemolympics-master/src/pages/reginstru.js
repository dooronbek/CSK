import React from "react";
import MyNavbar from "../components/MyNavbar";
import "../styles/reginstru.css"
import background from "../images/mainBackgroundImage.JPG";

const RegistrIns = () => {
    return (
        <>
      <MyNavbar />
      <div
        style={{
          backgroundImage: `url(${background})`,
          width: "100%",
          height: "100%",
        }}
      >
      <section className="content">
          <div className="container">
            <h2>Лига Аррениус</h2>
            <div className="sub-menu--global">
                <a href="/leagueArr/">О лиге </a>
                <a href="/reginstu/">Инструкция по оплате</a>

                <a href="https://linktr.ee/chemolympic">Регистрация </a>

                <a href="https://www.instagram.com/league.arrhenius/">Инстагам </a>

                <a href="https://t.me/chemolympics"> Телеграм</a>
              </div>
      <div>
        <h1>Иснтрукция по регистрации и оплате участия</h1>
      </div>
      <div class = "ow">
     
      <div className="block a2maintextblock ">

<div className="text-image-block hashtaglink">

    

        <div className="text-image-block__bd">

<p>Сначала надо зарегистрироваться <a href="https://linktr.ee/chemolympic">здесь.</a> А затем: <br/>
1) через платежные терминалы "Айыл Банк", Pay 24, Quick Pay, UMAI, заходите в раздел "Электронные кошельки" / или "Услуги банков" - и выбираете "MBank Online - поплнение" ;<br/>
2) набираете 996779854433;<br/>
3) вносите 200 сом;<br/>
4) забираете чек и отправляете на WhatsApp номер 0990-552-713;<br/>
5) вы успешно подтвердили свое участие в Лиге!

</p>
        </div>
            
</div>
</div></div></div></section>
<div>
<br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br /><br />
          <br />
          ——————————————————————————————————————————————————————————————————————————————
          <br />
          <br /><br />
          <br />
          <a
            className="mx-1 btn btn-danger margin"
            href="https://www.instagram.com/league.arrhenius/"
          >
            Инстаграм
          </a>
          <a
            className="mx-1 btn btn-primary margin"
            href="https://t.me/chemolympics"
          >
            Телеграм канал
          </a>
          <a
            className="mx-1 btn btn-info margin"
            href="https://linktr.ee/chemolympic"
          >
            Ссылка на регистрацию
          </a>
        </div>
</div>
    </>
    )
}

export default RegistrIns;