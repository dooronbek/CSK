import React from "react";
import { Document, Page, pdfjs } from "react-pdf";

import sample from "../../sample.pdf";
import juniorLeague from "./9_leagueArr.pdf"
import seniorLeague from "./11_leagueArr.pdf"
pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

const Pdf = (props) => {
  return (
    <div>
      <Document className="d-flex" file={sample}>
        <Page className="d-flex" pageNumber={props.pageNumber} />
      </Document>
    </div>
  );
};

export const JuniorLeague = (props) => {
  return (
    <div>
      <Document className="d-flex" file={juniorLeague}>
        <Page className="d-flex" pageNumber={props.pageNumber} />
      </Document>
    </div>
  );
};

export const SeniorLeague = (props) => {
  return (
    <div>
      <Document className="d-flex" file={seniorLeague}>
        <Page className="d-flex" pageNumber={props.pageNumber} />
      </Document>
    </div>
  );
};
export default Pdf;
