import React, { useEffect, useState } from "react";
import { auth, db } from "../../config/firebaseConfig";
import { onSnapshot, collection } from "@firebase/firestore";
import { useAuthState } from "react-firebase-hooks/auth";

import Pdf from "./Pdf";
import { JuniorLeague, SeniorLeague } from "./Pdf";
import "../../styles/Questions.css";

const Questions = () => {
  const [user] = useAuthState(auth);
  const [pageNumber, setPageNumber] = useState(1);
  const [isSenior, setIsSenior] = useState(0);

  const prevPageHandler = () => {
    if (pageNumber > 1) {
      setPageNumber(pageNumber - 1);
    }
  };
  const nextPageHandler = () => {
    if (pageNumber <= 34) {
      setPageNumber(pageNumber + 1);
    }
  };

  useEffect(() => {
    if (user) {
      onSnapshot(collection(db, "participants"), (snapshot) => {
        snapshot.docs.map((doc) => {
          if (doc.data().number === user.phoneNumber) {
            if (doc.data().grade === "10" || doc.data().grade === "11") {
              setIsSenior(1);
            } 
            else if (doc.data().grade === "8" || doc.data().grade === "9") {
              setIsSenior(2);
            } 
          }
          else {
            console.log("not true")
          };
          console.log(doc.data());
        });
      });
    }
  }, []);
  return (
    <div>
      {/* <Pdf pageNumber={pageNumber} /> */}
      {isSenior === 1&& <SeniorLeague pageNumber={pageNumber}/>}
      {isSenior === 2 && <JuniorLeague pageNumber={pageNumber}/>}
      <button className="btn btn-secondary" onClick={prevPageHandler}>
        Предыдущая страница{" "}
      </button>
      <button className="btn btn-secondary right" onClick={nextPageHandler}>
        Следующая страница
      </button>
    </div>
  );
};

export default Questions;
