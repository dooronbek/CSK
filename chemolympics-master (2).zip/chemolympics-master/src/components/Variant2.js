import React from "react";


const Variant2 = () => {

    const handleInputChange = (event) => {
        console.log("event", event.target);
        console.log(event.target.name);
        console.log(event.target.value);
    }; 
  return (
    <table>
      <thead>
        <tr>
          <td>&nbsp;</td>
          <td>А</td>
          <td>Б</td>
          <td>В</td>
          <td>Г</td>
        </tr>
      </thead>
      <tbody>
        <tr className="active">
          <td>
            <div className="num-test">1</div>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="1"
                type="radio"
                className="r_option"
                value="А"
                data-number="1"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_1_А"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="1"
                type="radio"
                className="r_option"
                value="Б"
                data-number="1"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_1_Б"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="1"
                type="radio"
                className="r_option"
                value="В"
                data-number="1"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_1_В"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="1"
                type="radio"
                className="r_option"
                value="Г"
                data-number="1"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_1_Г"></span>
            </label>
          </td>
        </tr>
        <input type="hidden" id="right_letter_1" value="Б" />
        <tr className="active">
          <td>
            <div className="num-test">2</div>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="2"
                type="radio"
                className="r_option"
                value="А"
                data-number="2"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_2_А"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="2"
                type="radio"
                className="r_option"
                value="Б"
                data-number="2"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_2_Б"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="2"
                type="radio"
                className="r_option"
                value="В"
                data-number="2"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_2_В"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="2"
                type="radio"
                className="r_option"
                value="Г"
                data-number="2"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_2_Г"></span>
            </label>
          </td>
        </tr>
        <input type="hidden" id="right_letter_2" value="Б" />
        <tr className="active">
          <td>
            <div className="num-test">3</div>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="3"
                type="radio"
                className="r_option"
                value="А"
                data-number="3"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_3_А"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="3"
                type="radio"
                className="r_option"
                value="Б"
                data-number="3"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_3_Б"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="3"
                type="radio"
                className="r_option"
                value="В"
                data-number="3"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_3_В"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="3"
                type="radio"
                className="r_option"
                value="Г"
                data-number="3"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_3_Г"></span>
            </label>
          </td>
        </tr>
        <input type="hidden" id="right_letter_3" value="А" />
        <tr className="active">
          <td>
            <div className="num-test">4</div>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="4"
                type="radio"
                className="r_option"
                value="А"
                data-number="4"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_4_А"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="4"
                type="radio"
                className="r_option"
                value="Б"
                data-number="4"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_4_Б"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="4"
                type="radio"
                className="r_option"
                value="В"
                data-number="4"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_4_В"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="4"
                type="radio"
                className="r_option"
                value="Г"
                data-number="4"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_4_Г"></span>
            </label>
          </td>
        </tr>
        <input type="hidden" id="right_letter_4" value="Б" />
        <tr className="active">
          <td>
            <div className="num-test">5</div>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="5"
                type="radio"
                className="r_option"
                value="А"
                data-number="5"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_5_А"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="5"
                type="radio"
                className="r_option"
                value="Б"
                data-number="5"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_5_Б"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="5"
                type="radio"
                className="r_option"
                value="В"
                data-number="5"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_5_В"></span>
            </label>
          </td>
          <td>
            <label className="expl-checkbox-label">
              <input
                name="5"
                type="radio"
                className="r_option"
                value="Г"
                data-number="5"
                data-first=""
                onChange={handleInputChange}
              />
              <span className="rcheck" id="span_5_Г"></span>
            </label>
          </td>
        </tr>
        <input type="hidden" id="right_letter_5" value="А" />
      </tbody>
    </table>
  );
};

export default Variant2;
