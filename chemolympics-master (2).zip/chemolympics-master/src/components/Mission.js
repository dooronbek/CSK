import React from "react";
import "../styles/mission.css";
const Mission = () => {
    return (
        <><div id="index_line">
            <div id="slider">
                <img alt="" height="240" src="images/logo2.jpg" width="450"></img></div>

            <div id="slider_description">
                <h1>Кыргызстан Химия Коому</h1>
                <p>Это сообщество было создано для объединения и сотрудничества наших граждан работающих или учащихся в химической сфере в Кыргызстане и за рубежом. Основной целью сообщества считается вклад в развитие химической отрасли Кыргызстана.</p>
            </div>


        </div><div>
                <div className="d-flex justify-content-center">
                    <h3>Наша миссия:</h3>
                </div>
                <div className="d-flex justify-content-center">
                    <ul className="w-25">
                        
                    </ul>
                </div>
            </div></>
    )
}

export default Mission;