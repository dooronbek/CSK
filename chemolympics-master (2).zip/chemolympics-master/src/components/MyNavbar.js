import React, { useState } from "react";
import { Link } from "react-router-dom";

import { auth } from "../config/firebaseConfig";
import { useAuthState } from "react-firebase-hooks/auth";

import {
  Collapse,
  Navbar,
  NavbarToggler,
  Nav,
  NavItem,
  NavLink,
  UncontrolledDropdown,
  DropdownToggle,
  DropdownMenu,
  DropdownItem,
} from "reactstrap";
import logo3 from "../images/logo3.png";
import "../styles/MyNavbar.css";

const MyNavbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const toggle = () => setIsOpen(!isOpen);
  const [user] = useAuthState(auth);

  return (
    <div>
      <Navbar color="light" light expand="md" style={{ fontSize: "20px" }}>
        <Link to="/" className="my-display">
          <img src={logo3} alt="Logo" className="logo" />
        </Link>
        <NavbarToggler onClick={toggle} />
        <Collapse isOpen={isOpen} navbar>
          <Nav className="mr-auto" navbar>
            <UncontrolledDropdown nav inNavbar>
              <DropdownToggle nav caret>
                КХК
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem>Устав</DropdownItem>
                <DropdownItem>Организационный комитет</DropdownItem>
                <DropdownItem divider />
                <DropdownItem>
                  <NavLink href="/news/">Новости</NavLink>
                </DropdownItem>
                <DropdownItem>
                  <NavLink href="/contacts/">Контакты</NavLink>
                </DropdownItem>
                <DropdownItem>О нас</DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
            <NavItem>
              <NavLink href="/journal/">Журнал</NavLink>
            </NavItem>
            <NavItem>
              <NavLink href="/seminar/">Научные семинары</NavLink>
            </NavItem>
            <UncontrolledDropdown nav inNavbar>
              <DropdownToggle nav caret>
                Олимпиады
              </DropdownToggle>
              <DropdownMenu right>
                <DropdownItem>
                  <NavLink href="/leaguearr/"> Лига Аррениус </NavLink>
                </DropdownItem>
                <DropdownItem>Альтернативная Олимпиада</DropdownItem>
              </DropdownMenu>
            </UncontrolledDropdown>
          </Nav>
          {/* {!user && <NavLink href="/register">Регистрация</NavLink>} */}
          {!user && (
            <NavLink href="/login" className="float-right">
              Логин
            </NavLink>
          )}
          {user && <NavLink href="/exam">Экзамен</NavLink>}
          {user && <button type="button" className="btn btn-danger" onClick={() => {auth.signOut()}}>Выход</button>}
          {user && user.phoneNumber === "+996505551731" && <NavLink href="/admin">Регистрация участников </NavLink>}
        </Collapse>
      </Navbar>
    </div>
  );
};

export default MyNavbar;
