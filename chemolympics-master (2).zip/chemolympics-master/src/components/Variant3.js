import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { examActions } from "../store/slices/examSlice";
import "../styles/Variant3.css"

const Variant3 = () => {
    const dispatch = useDispatch();
    const answers = useSelector((state) => state.exam.examAnswer);

    const handleInputChange = (event) => {
        const answerName = event.target.name;
        const answerValue = event.target.value;

        const myAnswer = {
            name: answerName,
            value: answerValue
        }
        // console.log("event is", event.target);
        // console.log(event.target.name);
        // console.log(event.target.value);
        dispatch(examActions.putAnswer(myAnswer));
    };

    useEffect(() => {
        console.log("answers are", answers)
    })
  return (
    <div id="options">
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="active">
                <td>
                  <div className="num-test">1</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="1"
                      type="radio"
                      className="r_option"
                      value="А"
                      data-number="1"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_1_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="1"
                      type="radio"
                      className="r_option"
                      value="Б"
                      data-number="1"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_1_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="1"
                      type="radio"
                      className="r_option"
                      value="В"
                      data-number="1"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_1_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="1"
                      type="radio"
                      className="r_option"
                      value="Г"
                      data-number="1"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_1_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_1" value="Б" />
              <tr className="active">
                <td>
                  <div className="num-test">2</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="2"
                      type="radio"
                      className="r_option"
                      value="А"
                      data-number="2"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_2_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="2"
                      type="radio"
                      className="r_option"
                      value="Б"
                      data-number="2"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_2_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="2"
                      type="radio"
                      className="r_option"
                      value="В"
                      data-number="2"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_2_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="2"
                      type="radio"
                      className="r_option"
                      value="Г"
                      data-number="2"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_2_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_2" value="Б" />
              <tr className="active">
                <td>
                  <div className="num-test">3</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="3"
                      type="radio"
                      className="r_option"
                      value="А"
                      data-number="3"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_3_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="3"
                      type="radio"
                      className="r_option"
                      value="Б"
                      data-number="3"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_3_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="3"
                      type="radio"
                      className="r_option"
                      value="В"
                      data-number="3"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_3_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="3"
                      type="radio"
                      className="r_option"
                      value="Г"
                      data-number="3"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_3_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_3" value="А" />
              <tr className="active">
                <td>
                  <div className="num-test">4</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="4"
                      type="radio"
                      className="r_option"
                      value="А"
                      data-number="4"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_4_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="4"
                      type="radio"
                      className="r_option"
                      value="Б"
                      data-number="4"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_4_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="4"
                      type="radio"
                      className="r_option"
                      value="В"
                      data-number="4"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_4_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="4"
                      type="radio"
                      className="r_option"
                      value="Г"
                      data-number="4"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_4_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_4" value="Б" />
              <tr className="active">
                <td>
                  <div className="num-test">5</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="5"
                      type="radio"
                      className="r_option"
                      value="А"
                      data-number="5"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_5_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="5"
                      type="radio"
                      className="r_option"
                      value="Б"
                      data-number="5"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_5_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="5"
                      type="radio"
                      className="r_option"
                      value="В"
                      data-number="5"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_5_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="5"
                      type="radio"
                      className="r_option"
                      value="Г"
                      data-number="5"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_5_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_5" value="А" />
            </tbody>
          </table>
        </div>
      </div>
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="active">
                <td>
                  <div className="num-test">6</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="6"
                      type="radio"
                      className="r_option"
                      value="А"
                      data-number="6"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_6_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="6"
                      type="radio"
                      className="r_option"
                      value="Б"
                      data-number="6"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_6_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="6"
                      type="radio"
                      className="r_option"
                      value="В"
                      data-number="6"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_6_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="6"
                      type="radio"
                      className="r_option"
                      value="Г"
                      data-number="6"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_6_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_6" value="В" />
              <tr className="not_active">
                <td>
                  <div className="num-test">7</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="7"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="7"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_7_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="7"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="7"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_7_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="7"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="7"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_7_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="7"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="7"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_7_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_7" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">8</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="8"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="8"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_8_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="8"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="8"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_8_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="8"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="8"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_8_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="8"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="8"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_8_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_8" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">9</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="9"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="9"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_9_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="9"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="9"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_9_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="9"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="9"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_9_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="9"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="9"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_9_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_9" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">10</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="10"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="10"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_10_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="10"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="10"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_10_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="10"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="10"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_10_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="10"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="10"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_10_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_10" value="" />
            </tbody>
          </table>
        </div>
      </div>
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="not_active">
                <td>
                  <div className="num-test">11</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="11"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="11"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_11_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="11"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="11"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_11_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="11"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="11"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_11_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="11"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="11"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_11_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_11" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">12</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="12"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="12"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_12_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="12"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="12"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_12_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="12"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="12"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_12_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="12"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="12"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_12_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_12" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">13</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="13"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="13"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_13_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="13"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="13"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_13_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="13"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="13"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_13_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="13"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="13"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_13_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_13" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">14</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="14"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="14"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_14_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="14"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="14"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_14_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="14"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="14"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_14_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="14"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="14"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_14_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_14" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">15</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="15"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="15"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_15_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="15"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="15"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_15_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="15"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="15"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_15_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="15"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="15"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_15_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_15" value="" />
            </tbody>
          </table>
        </div>
      </div>
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="not_active">
                <td>
                  <div className="num-test">16</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="16"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="16"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_16_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="16"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="16"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_16_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="16"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="16"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_16_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="16"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="16"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_16_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_16" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">17</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="17"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="17"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_17_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="17"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="17"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_17_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="17"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="17"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_17_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="17"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="17"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_17_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_17" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">18</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="18"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="18"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_18_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="18"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="18"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_18_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="18"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="18"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_18_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="18"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="18"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_18_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_18" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">19</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="19"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="19"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_19_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="19"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="19"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_19_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="19"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="19"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_19_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="19"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="19"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_19_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_19" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">20</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="20"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="20"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_20_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="20"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="20"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_20_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="20"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="20"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_20_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="20"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="20"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_20_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_20" value="" />
            </tbody>
          </table>
        </div>
      </div>
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="not_active">
                <td>
                  <div className="num-test">21</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="21"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="21"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_21_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="21"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="21"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_21_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="21"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="21"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_21_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="21"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="21"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_21_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_21" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">22</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="22"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="22"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_22_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="22"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="22"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_22_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="22"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="22"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_22_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="22"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="22"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_22_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_22" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">23</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="23"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="23"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_23_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="23"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="23"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_23_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="23"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="23"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_23_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="23"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="23"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_23_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_23" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">24</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="24"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="24"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_24_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="24"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="24"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_24_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="24"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="24"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_24_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="24"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="24"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_24_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_24" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">25</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="25"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="25"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_25_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="25"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="25"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_25_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="25"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="25"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_25_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="25"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="25"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_25_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_25" value="" />
            </tbody>
          </table>
        </div>
      </div>
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="not_active">
                <td>
                  <div className="num-test">26</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="26"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="26"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_26_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="26"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="26"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_26_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="26"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="26"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_26_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="26"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="26"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_26_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_26" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">27</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="27"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="27"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_27_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="27"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="27"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_27_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="27"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="27"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_27_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="27"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="27"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_27_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_27" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">28</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="28"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="28"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_28_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="28"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="28"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_28_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="28"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="28"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_28_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="28"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="28"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_28_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_28" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">29</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="29"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="29"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_29_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="29"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="29"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_29_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="29"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="29"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_29_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="29"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="29"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_29_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_29" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">30</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="30"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="30"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_30_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="30"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="30"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_30_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="30"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="30"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_30_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="30"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="30"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_30_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_30" value="" />
            </tbody>
          </table>
        </div>
      </div>
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="not_active">
                <td>
                  <div className="num-test">31</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="31"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="31"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_31_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="31"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="31"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_31_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="31"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="31"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_31_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="31"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="31"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_31_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_31" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">32</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="32"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="32"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_32_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="32"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="32"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_32_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="32"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="32"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_32_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="32"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="32"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_32_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_32" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">33</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="33"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="33"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_33_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="33"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="33"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_33_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="33"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="33"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_33_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="33"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="33"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_33_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_33" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">34</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="34"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="34"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_34_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="34"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="34"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_34_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="34"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="34"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_34_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="34"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="34"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_34_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_34" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">35</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="35"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="35"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_35_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="35"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="35"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_35_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="35"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="35"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_35_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="35"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="35"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_35_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_35" value="" />
            </tbody>
          </table>
        </div>
      </div>
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="not_active">
                <td>
                  <div className="num-test">36</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="36"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="36"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_36_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="36"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="36"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_36_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="36"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="36"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_36_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="36"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="36"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_36_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_36" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">37</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="37"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="37"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_37_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="37"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="37"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_37_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="37"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="37"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_37_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="37"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="37"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_37_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_37" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">38</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="38"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="38"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_38_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="38"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="38"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_38_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="38"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="38"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_38_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="38"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="38"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_38_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_38" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">39</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="39"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="39"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_39_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="39"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="39"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_39_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="39"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="39"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_39_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="39"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="39"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_39_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_39" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">40</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="40"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="40"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_40_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="40"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="40"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_40_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="40"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="40"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_40_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="40"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="40"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_40_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_40" value="" />
            </tbody>
          </table>
        </div>
      </div>
      <div className="col-blog">
        <div className="abcd_option">
          <table>
            <thead>
              <tr>
                <td>&nbsp;</td>
                <td>А</td>
                <td>Б</td>
                <td>В</td>
                <td>Г</td>
              </tr>
            </thead>
            <tbody>
              <tr className="not_active">
                <td>
                  <div className="num-test">41</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="41"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="41"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_41_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="41"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="41"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_41_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="41"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="41"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_41_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="41"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="41"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_41_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_41" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">42</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="42"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="42"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_42_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="42"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="42"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_42_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="42"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="42"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_42_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="42"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="42"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_42_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_42" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">43</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="43"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="43"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_43_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="43"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="43"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_43_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="43"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="43"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_43_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="43"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="43"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_43_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_43" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">44</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="44"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="44"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_44_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="44"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="44"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_44_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="44"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="44"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_44_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="44"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="44"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_44_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_44" value="" />
              <tr className="not_active">
                <td>
                  <div className="num-test">45</div>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="45"
                      type="radio"
                      
                      className="r_option"
                      value="А"
                      data-number="45"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_45_А"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="45"
                      type="radio"
                      
                      className="r_option"
                      value="Б"
                      data-number="45"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_45_Б"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="45"
                      type="radio"
                      
                      className="r_option"
                      value="В"
                      data-number="45"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_45_В"></span>
                  </label>
                </td>
                <td>
                  <label className="expl-checkbox-label">
                    <input
                      name="45"
                      type="radio"
                      
                      className="r_option"
                      value="Г"
                      data-number="45"
                      data-first=""
                      onChange={handleInputChange}
                    />
                    <span className="rcheck" id="span_45_Г"></span>
                  </label>
                </td>
              </tr>
              <input type="hidden" id="right_letter_45" value="" />
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Variant3;
