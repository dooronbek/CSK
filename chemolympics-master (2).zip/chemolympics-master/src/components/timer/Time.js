import React, { useEffect } from "react";
import { CountdownCircleTimer } from "react-countdown-circle-timer";
import { useSelector, useDispatch } from "react-redux";
import { startExamActions } from "../../store/slices/startExamSlice";
import "../../styles/Time.css";

const minuteSeconds = 60;
const hourSeconds = 3600;
const daySeconds = 86400;

const timerProps = {
  isPlaying: true,
  size: 80,
  strokeWidth: 3,
};

const renderTime = (dimension, time) => {
  return (
    <div className="time-wrapper">
      <div className="time">{time}</div>
      <div>{dimension}</div>
    </div>
  );
};

const getTimeSeconds = (time) => (minuteSeconds - time) | 0;
const getTimeMinutes = (time) => ((time % hourSeconds) / minuteSeconds) | 0;
const getTimeHours = (time) => ((time % daySeconds) / hourSeconds) | 0;

const Time = () => {
  const dispatch = useDispatch();
  let startTime = 75600;
  // useSelector((state) => state.startExam.startTime);
  // startTime = 75600; //start time is gonna change to 36000   
  console.log("time is", startTime)
  const endTime = 41700;
  // useSelector((state) => state.startExam.endTime); // endTime is gonna 41700
  const remainingTime = endTime - startTime;

  useEffect(() => {
    console.log("time", startTime, endTime);
    console.log("remaining time", remainingTime);
    dispatch(startExamActions.updateTime());
  });

  return (
    <div className="my-time">
      <CountdownCircleTimer
        {...timerProps}
        colors={[["#D14081"]]}
        duration={daySeconds}
        initialRemainingTime={remainingTime % daySeconds}
        onComplete={(totalElapsedTime) => [
          remainingTime - totalElapsedTime > hourSeconds,
        ]}
      >
        {({ elapsedTime }) =>
          renderTime("Час", getTimeHours(daySeconds - elapsedTime))
        }
      </CountdownCircleTimer>
      <CountdownCircleTimer
        {...timerProps}
        colors={[["#EF798A"]]}
        duration={hourSeconds}
        initialRemainingTime={remainingTime % hourSeconds}
        onComplete={(totalElapsedTime) => [
          remainingTime - totalElapsedTime > minuteSeconds,
        ]}
      >
        {({ elapsedTime }) =>
          renderTime("Минут", getTimeMinutes(hourSeconds - elapsedTime))
        }
      </CountdownCircleTimer>
      <CountdownCircleTimer
        {...timerProps}
        colors={[["#218380"]]}
        duration={minuteSeconds}
        initialRemainingTime={remainingTime % minuteSeconds}
        onComplete={(totalElapsedTime) => {
          if (remainingTime - totalElapsedTime <= 0) {
            console.log("exam is finished");
            dispatch(startExamActions.finishExam());

          }
          return [remainingTime - totalElapsedTime > 0];
        }}
      >
        {({ elapsedTime }) => renderTime("Секунд", getTimeSeconds(elapsedTime))}
      </CountdownCircleTimer>
    </div>
  );
};

export default Time;
