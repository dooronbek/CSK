import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { examActions } from "../../store/slices/examSlice";

const Variant = (props) => {
  const dispatch = useDispatch();
  const answers = useSelector((state) => state.exam.examAnswer);

  const handleChange = (event) => {
    const questionNumber = event.target.name;
    const answer = event.target.value;
    const myAnswer = {
      questionNumber,
      answer,
    };
    dispatch(examActions.putAnswer(myAnswer));
  };
  useEffect(() => {
    console.log("answers are", answers);
  }, [answers]);
  return (
    <div>
      <label>{props.order}&nbsp;</label>
      <input type="radio" name={props.name} value="А" onChange={handleChange} />
      <label>А</label>
      &nbsp;
      <input type="radio" name={props.name} value="Б" onChange={handleChange} />
      <label>Б</label>
      &nbsp;
      <input type="radio" name={props.name} value="В" onChange={handleChange} />
      <label>В</label>
      &nbsp;
      <input type="radio" name={props.name} value="Г" onChange={handleChange} />
      <label>Г</label>
    </div>
  );
};

export default Variant;
