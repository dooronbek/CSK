import React from "react";
import Variant from "./Variant";
import "./index.css"

export const FirstPart = () => {
  const firstPart = [];
  for (let i = 1; i < 23; i++) {
    firstPart.push(i);
  }
  return (
    <div className="d-inline margin">
      {firstPart.map((questionNumber) => (
        <div key={questionNumber} className="d-inline">
          <Variant name={questionNumber} order={questionNumber} />
          <br />
        </div>
      ))}
    </div>
  );
};

export const SecondPart = () => {
  const secondPart = [];
  for (let i = 23; i < 46; i++) {
    secondPart.push(i);
  }
  return (
    <div className="d-inline margin">
      {secondPart.map((questionNumber) => (
        <div key={questionNumber} className="d-inline">
          <Variant name={questionNumber} order={questionNumber} />
          <br />
        </div>
      ))}
    </div>
  );
};
